import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class StringManipulationTest {
    @Test
    public void testToPostfix() {
        String infix = "1 + 2 * 3";
        String expected = "1 2 3 *+";
        String result = StringManipulation.toPostfix(infix);
        assertEquals(expected, result);
        infix = " 28 * 3 + (71-53) / 14";
        result = StringManipulation.toPostfix(infix);
        expected = "28 3 * 71 53 - 14 /+";
        assertEquals(expected, result);

        assertEquals("10 5 + 2 3 + 5 4 - 3 * / 2 * -",
                StringManipulation.toPostfix("10 + 5 - ( ( 2 + 3 ) / ( ( 5 - 4 ) * 3 ) ) * 2"));
    }

    @Test
    public void testResult() {
        String postfix = "1 2 3 *+";
        int expected = 7;
        int result = StringManipulation.result(postfix);
        assertEquals(expected, result);
        postfix = "28 3 * 71 53 - 14 /+";
        expected = 85;
        result = StringManipulation.result(postfix);
        assertEquals(85, result);
    }
    @Test
    public void testSmallestNumber() {
        String number = "70004";
        int n = 1;
        String expected = "4";
        String result = StringManipulation.smallestNumber(number, n);
        assertEquals(expected, result);
        String num2 = "57692";
        result = StringManipulation.smallestNumber(num2, 2);
        assertEquals("562", result);
    }
    @Test
    public void testUnbelievableString() {
        String s = "abDDdddE";
        String expected = "abdE";
        String result = StringManipulation.unbelievableString(s);
        assertEquals(expected, result);
        String z = "cCDDeFfGhiI";
        result = StringManipulation.unbelievableString(z);
        assertEquals("DDeGh", result);
    }
}
