public class StringManipulation {

    /**
     *
     * @param infix: Arithmetic expression in infix format
     * @return postFix equivalent of given expression
     */
    public static String toPostfix(String infix) {
        Stack<Character> stack = new Stack<>();
        String postFix = "";
        for (int i = 0; i < infix.length(); i++) {
            Character token = infix.charAt(i);
            switch (token){
                case '/':
                case '+':
                case '-':
                case '*':
                    //Add a space to output
                    postFix += " ";
                    // Pop all operators of higher or equal precedence from stack and output to postFix.
                    while(!stack.isEmpty()){
                        //Do not pop left parenthesis
                        if (stack.peek() == '('){
                            break;
                        }
                        if (getPrecedence(stack.peek()) >= getPrecedence(token)){
                            Character op = stack.pop();
                            postFix += op;
                        }
                        else {
                            break;
                        }
                    }
                    stack.push(token);
                    break;
                case '(':
                    postFix += " ";
                    stack.push(token);
                    break;
                case ')':
                    postFix += " ";
                    while(!stack.isEmpty()){
                        Character op = stack.pop();
                        if(op != '('){
                            postFix += op;
                        }
                        else{
                            break;
                        }
                    }
                    break;
                case ' ':
                    //Ignore whitespaces.
                    break;
                default:
                    postFix += token;
            }
        }
        // Pop any remaining operators from the stack and append to output
        if (!stack.isEmpty()){
            postFix += " ";
        }
        while(!stack.isEmpty()) {
            Character op = stack.pop();
            if (op != '(') {
                postFix += op;
            }
        }
        return postFix;
    }

    private static int getPrecedence(Character op){
        // Assigns precedence values to each operator. Higher means more precedence.
        switch (op){
            case '-':
                return 1;
            case '+':
                return 1;
            case '/':
                return 2;
            case '*':
                return 2;
            case ')':
                return 3;
            case '(':
                return 3;
        }
        return 0;
    }
    public static int result(String postfix) {
        Stack<Integer> stack = new Stack<>();
        for (String token : postfix.split(" ")) {
            //Checks to see if the token is a digit or set of digits, in which case it parses the String and adds
            //to the stack.
            if (token.matches("\\d+")) {
                stack.push(Integer.parseInt(token));
            } else {
                for (int i = 0; i < token.length(); i++) {
                    Character op = token.charAt(i);
                    int b = stack.pop();
                    int a = stack.pop();
                    // performs mathematical operation dependent on which operator is encountered
                    switch (op) {
                        case '+':
                            stack.push(a + b);
                            break;
                        case '-':
                            stack.push(a - b);
                            break;
                        case '*':
                            stack.push(a * b);
                            break;
                        case '/':
                            stack.push(a / b);
                            break;
                        default:
                            System.err.println("Operator not handled! " + op);
                    }
                }
            }
        }
        return stack.pop();
    }

    public static String smallestNumber(String number, int n) {
        String smallestNum =  new String(number);
        for (int i = 0; i < n; i++) {
            smallestNum = findSmallestAfterOne(smallestNum);
        }
        return smallestNum;
    }
    private static String findSmallestAfterOne(String number){
        long min = 0;
        for (int i = 0; i < number.length() - 1; i++) {
            String oneDel = number.substring(0, i) + number.substring(i+1);
            long num = Long.parseLong(oneDel);
            if (i == 0){
                min = num;
            }
            //checks to see if the newly made temporary number is smaller than the current minimum value.
            // if it is, then the number is assigned to be the new minimum value.
            else if (num < min){
                min = num;
            }
        }
        return Long.toString(min);
    }

    public static String unbelievableString(String s) {
        boolean found;
        do {
            found = false;
            for (int i = 0; i < s.length() - 1; i++) {
                Character ch1 = s.charAt(i);
                Character ch2 = s.charAt(i+1);
                if (Character.isLowerCase(ch1)){
                    Character upper = Character.toUpperCase(ch1);
                    if (upper == ch2){
                        s = s.substring(0, i) + s.substring(i+2);
                        found = true;
                    }
                }
                else if (Character.isUpperCase(ch1)) {
                    Character lower = Character.toLowerCase(ch1);
                    if (lower == ch2){
                        s = s.substring(0, i) + s.substring(i+2);
                        found = true;
                    }
                }
            }
        } while (found);
        return s;
    }

}
